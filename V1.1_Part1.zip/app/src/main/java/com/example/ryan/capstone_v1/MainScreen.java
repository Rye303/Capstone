/*
Capstone Phone App:
Version 1.1
Nov 10, 2016

Has:
Manual type location data for start and finish locations
Send data to a separate phone app screen to simulate data transmission to the Pi
Button on the Overview of data sent page enables user to go back to main screen and input more data

Needs:
Drag and drop / menu items for location
send data to Pi
Receive data from Pi

 */

package com.example.ryan.capstone_v1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;

public class MainScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_screen);
    }

    // Send Data when "Send Data" button is clicked
    public void onClick(View view){
        Intent i = new Intent(this, Screen2.class);

        // Edit the Text "Location_A_Input"
        final EditText Location_A_Input = (EditText) findViewById(R.id.Location_A_Input) ;
        // location_A_data = the string of what you typed
        String location_A_data = Location_A_Input.getText().toString();
        // Put the string data into a pile to be thrown to the send screen and name the string "LocationA"
        i.putExtra("LocationA",location_A_data);

        final EditText Location_B_Input = (EditText) findViewById(R.id.Location_B_Input) ;
        String location_B_data = Location_B_Input.getText().toString();
        i.putExtra("LocationB",location_B_data);

        // go to activity "i" = Screen2
        startActivity(i);
    }
}

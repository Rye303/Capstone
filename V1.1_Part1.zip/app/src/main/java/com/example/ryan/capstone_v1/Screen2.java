package com.example.ryan.capstone_v1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);

        Bundle MainData = getIntent().getExtras();
        if(MainData == null){
            return;
        }
        String LocationA = MainData.getString("LocationA");
        final TextView SendA = (TextView)findViewById(R.id.Send_A);
        SendA.setText(LocationA);

        String LocationB = MainData.getString("LocationB");
        final TextView SendB = (TextView)findViewById(R.id.Send_B);
        SendB.setText(LocationB);
    }

    public void onClick(View view){
        Intent i = new Intent(this, MainScreen.class);
        startActivity(i);
    }

}
